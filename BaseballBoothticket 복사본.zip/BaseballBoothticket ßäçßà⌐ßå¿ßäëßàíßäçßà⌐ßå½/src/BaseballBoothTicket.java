
public class BaseballBoothTicket {

}
